package com.alexandrsharov.Lab_1_Sharov.practice

class StringsExercise {
    val text = "nine one nine!! two three nine eight... eight eight, five four four two three six six eight"

    var map = mutableMapOf("a" to 0)
    val clearText = text.replace("[!,.?\n]".toRegex(), "")
    val words = clearText.split(" ").filter{it.all{it.isLetter()}}.map {it.lowercase()}.sorted()  //Выводим из текста слова, убираем регистр и сортируем их
    fun wordsWithCounts(): MutableMap<String, Int> {
        map.clear()
        var counter = 1
        for (i in 0..words.size - 2){
            if (words.get(i).equals(words.get(i+1))){        //Сравниваем тек. элемент и следующий
                counter++
            } else {
                map.put(words.get(i), counter)
                counter = 1
            }
        }
        if (words.get((words.size-1)).equals(words.get((words.size-2)))){
            map.put(words.get((words.size-1)), counter)
        } else {
            map.put(words.get((words.size-1)), 1)
        }
        return map
    }

    var inputData: String
        get() = text
        set(value) {}

    var result: String
        get() = "Words + word counts: " + wordsWithCounts().toString()
        set(value) {}
}