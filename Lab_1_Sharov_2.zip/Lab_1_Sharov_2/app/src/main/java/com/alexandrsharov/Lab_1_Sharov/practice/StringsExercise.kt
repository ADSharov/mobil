package com.alexandrsharov.Lab_1_Sharov.practice

class StringsExercise {
    val text = "nine one nine!! two three nine eight... eight eight, five four four two three six six eight"

    val clearText = text.replace("[!,.?\n]".toRegex(), "")
    val words = clearText.split(" ").filter{it.all{it.isLetter()}}.map {it.lowercase()}  //Выводим из текста слова, убираем регистр и сортируем их
    val answer = words.groupingBy { it }.eachCount()

    var inputData: String
        get() = text
        set(value) {}

    var result: String
        get() = "Words + word counts: " + answer
        set(value) {}
}